import React, { useState, useEffect } from "react";
import "../Buyingcommprope/Buyicommproperty.css";
import Buyerleadform from "./Buyerleadform";

const Residentialbuye = () => {
  const [properties, setProperties] = useState([]);
  const [showPopup, setShowPopup] = useState(false);
  const [selectedProperty, setSelectedProperty] = useState(null);
  useEffect(() => {
    fetch("http://localhost:5000/buyer/properties")
      .then(res => res.json())
      .then(data => setProperties(data))
  }, []);

  const formatPrice = (price) => {
    if (!price) return "";

    price = Number(price);

    if (price >= 10000000) {
      return (price / 10000000).toFixed(2) + " Cr";
    } else if (price >= 100000) {
      return (price / 100000).toFixed(2) + " Lakh";
    } else {
      return price.toLocaleString("en-IN");
    }
  };

  return (
    <>

      <div className="listing-page">

        <div className="listing-container">
          <aside className="filters">
            <h4>Applied Filters</h4>
            <button className="filter-btn">Owner ✕</button>
            <button className="filter-btn">₹40L - ₹60L ✕</button>
          </aside>
          <div>
            <h2 className="page-title">Residential land / Plots in Central Delhi for Sale Posted By Dealer</h2>

            {Array.isArray(properties) && properties.length > 0 ? (
              properties.map(item => (
                <div key={item.id} className="property-card">

                  {/* Image */}
                  <img
                    src={item.image_url}
                    alt={item.title}
                    style={{
                      width: "429px",
                      height: "274px",
                      objectFit: "cover",
                      borderRadius: "6px",
                      paddingTop: "3px",
                      paddingLeft: "2px"
                    }}
                  />


                  {/* Content */}
                  <div className="property-info">
                    <h2 className="property-title">{item.title}</h2>
                    <div className="property-loc">
                      <span className="subtype">{item.subtype}</span>
                      <span className="property-location">{item.location}</span>
                    </div>
                    <div className="property-meta">
                      <span
                        className="price"
                        title={`₹${Number(item.estimated_price).toLocaleString("en-IN")}`}
                      >
                        ₹{formatPrice(item.estimated_price)}
                      </span>


                      <span className="property-desc">{item.description}</span>


                      <span className="type">{item.type}</span>

                    </div> 
                    <div className="info-footer"> 
                      <div className="actio-butto">
                        <button
                          className="view-btn"
                          onClick={() => {
                            setSelectedProperty(item);
                            setShowPopup(true);
                          }}
                        >
                          View Number
                        </button>
                        <button className="contact-btn">Contact</button>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <p>No properties found</p>
            )}

          </div>

        </div>
      </div>
      {/* 🔥 POPUP */}
      {showPopup && (
        <Buyerleadform
          property={selectedProperty}
          onClose={() => setShowPopup(false)}
        />
      )}
    </>

  );
};

export default Residentialbuye;
