import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import banner from "../image/banner5.jpg";
import "../Banner/Homep.css";

const Homepag = () => {
  const [userName, setUserName] = useState(null);
  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    localStorage.removeItem("name");
    setUserName(null);
  };


  return (
    <div className="home">

      {/* Banner Section */}
      <section className="hero">

        {/* Animated Image */}
        <motion.img
          src={banner}
          alt="Home Banner"
          className="hero-img"
          initial={{ scale: 1.1 }}
          animate={{ scale: 1 }}
          transition={{ duration: 1.5 }}
        />

        {/* Content */}
        <motion.div
          className="hero-content"
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
        >
          <motion.h1
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            Welcome to <br />
            Syn X Real Estate & Advisory
          </motion.h1>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
          >
            Platform for Smart Investments
          </motion.p>

          <motion.button
            className="hero-btn"
            whileHover={{ scale: 1.08 }}
            whileTap={{ scale: 0.95 }}
          >
            Explore Properties
          </motion.button>
        </motion.div>
<div className="auth">
        {!userName ? (
          <>
            <Link to="/Loging" className="btn-outline">Login</Link>
            <Link to="/Signup" className="btn-primary">Sign Up</Link>
          </>
        ) : (
          <div className="user-menu">
            <span className="user-name"> {userName}</span>
            <button className="btn-outline" onClick={handleLogout}>Logout</button>
          </div>
        )}
      </div>
      </section>
      {/* <div className="auth">
        {!userName ? (
          <>
            <Link to="/Loging" className="btn-outline">Login</Link>
            <Link to="/Signup" className="btn-primary">Sign Up</Link>
          </>
        ) : (
          <div className="user-menu">
            <span className="user-name"> {userName}</span>
            <button className="btn-outline" onClick={handleLogout}>Logout</button>
          </div>
        )}
      </div> */}
    </div>
  );
};

export default Homepag;
