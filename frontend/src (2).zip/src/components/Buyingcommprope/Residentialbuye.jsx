import React, { useState, useEffect } from "react";
import "../Buyingcommprope/Buyicommproperty.css";
import Buyerleadform from "./Buyerleadform";

const Residentialbuye = () => {
  const [properties, setProperties] = useState([]);
  const [showPopup, setShowPopup] = useState(false);
  const [selectedProperty, setSelectedProperty] = useState(null);

  // Slider state for each property
  const [currentSlide, setCurrentSlide] = useState({});

  useEffect(() => {
    fetch("http://localhost:5000/buyer/properties")
      .then(res => res.json())
      .then(data => setProperties(data))
      .catch(err => console.log(err));
  }, []);

  const formatPrice = (price) => {
    if (!price) return "";
    price = Number(price);

    if (price >= 10000000) return (price / 10000000).toFixed(2) + " Cr";
    if (price >= 100000) return (price / 100000).toFixed(2) + " Lakh";
    return price.toLocaleString("en-IN");
  };

  const nextSlide = (id, length) => {
    setCurrentSlide(prev => ({
      ...prev,
      [id]: prev[id] === undefined ? 1 : (prev[id] + 1) % length
    }));
  };

  const prevSlide = (id, length) => {
    setCurrentSlide(prev => ({
      ...prev,
      [id]: prev[id] === undefined ? length - 1 : (prev[id] - 1 + length) % length
    }));
  };

  return (
    <>
      <div className="listing-page">
        <div className="listing-container">

          <aside className="filters">
            <h4>Applied Filters</h4>
            <button className="filter-btn">Owner ✕</button>
            <button className="filter-btn">₹40L - ₹60L ✕</button>
          </aside>

          <div>
            <h2 className="page-title">
              Residential land / Plots for Sale
            </h2>

            {properties.length > 0 ? (
              properties.map(item => (
                <div key={item.id} className="property-card">

                  <div className="slider-container">
                    {item.images && item.images.length > 0 ? (
                      <>
                        <img
                          src={item.images[currentSlide[item.id] || 0]}
                          alt={item.title}
                          className="slider-img"
                        />
                        {item.images.length > 1 && (
                          <>
                            <button
                              className="slider-btn prev"
                              onClick={() => prevSlide(item.id, item.images.length)}
                            >
                              ❮
                            </button>
                            <button
                              className="slider-btn next"
                              onClick={() => nextSlide(item.id, item.images.length)}
                            >
                              ❯
                            </button>
                          </>
                        )}
                      </>
                    ) : (
                      <div className="no-img">No Image</div>
                    )}
                  </div>

                  {/* CONTENT */}
                  <div className="property-info">
                    {/* <h2 className="property-title">{item.title}</h2> */}

                    <div className="property-loc">
                      <span>{item.location}</span>

                      <span className="subtype">{item.subtype}</span>
                    </div>

                    <div className="property-meta">
                      <span className="price">
                        ₹{formatPrice(item.estimated_price)}
                      </span>
                      <span className="sqls">{item.description}</span>
                      <span>{item.type}</span>
                    </div>
                    <div>
                      <h3 className="property-title">{item.title}</h3>

                    </div>
                    <div className="info-footer">
                      <button
                        className="view-btn"
                        onClick={() => {
                          setSelectedProperty(item);
                          setShowPopup(true);
                        }}
                      >
                        View Number
                      </button>
                      <button className="contact-btn">Contact</button>
                    </div>
                  </div>

                </div>
              ))
            ) : (
              <p>No properties found</p>
            )}
          </div>

        </div>
      </div>

      {showPopup && (
        <Buyerleadform
          property={selectedProperty}
          onClose={() => setShowPopup(false)}
        />
      )}
    </>
  );
};

export default Residentialbuye;
