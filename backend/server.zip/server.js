
const express = require("express");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const cors = require("cors");
const mysql = require("mysql2/promise");
const multer = require("multer");
const path = require("path");
const fs= require('fs');



const app = express();

// MySQL Pool
const db = mysql.createPool({
  host: "localhost",
  user: "root",
  password: "",
  database: "synx_platform",
  //  port: 3306
});

// Check DB Connection
async function testDB() {
  try {
    const connection = await db.getConnection();
    console.log("✅ MySQL Connected!");
    connection.release();
  } catch (err) {
    console.log("❌ MySQL Connection Failed:", err);
  }
}

testDB();



// Storage
if (!fs.existsSync("./uploads")) {
  fs.mkdirSync("./uploads");
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "./uploads/");
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});

const upload = multer({ storage });
// Middleware
app.use(cors());
app.use(express.json());
// static uploads folder (important)
app.use("/uploads", express.static("uploads"));


// Auth Middleware
function auth(req, res, next) {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(401).json({ msg: "No token" });

  try {
    const decoded = jwt.verify(token, "SECRETKEY");
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ msg: "Invalid token" });
  }
}

// REGISTER
app.post("/register", async (req, res) => {
  try {
    const { name, email, password, role } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ msg: "All fields required" });
    }

    const [existing] = await db.execute("SELECT * FROM userss WHERE email=?", [email]);
    if (existing.length > 0) {
      return res.status(400).json({ msg: "Email already exists" });
    }

    const hashed = await bcrypt.hash(password, 10);

    await db.execute(
      "INSERT INTO userss (name, email, password, role) VALUES (?,?,?,?)",
      [name, email, hashed, role || "buyer"]
    );

    return res.json({ msg: "Registered successfully" });

  } catch (err) {
    console.log(err);
    return res.status(500).json({ msg: "Server error" });
  }
});

// LOGIN
app.post("/loging", async (req, res) => {
  try {
    const { email, password } = req.body;
    const [user] = await db.execute("SELECT * FROM userss WHERE email=?", [email]);

    if (user.length === 0) return res.status(400).json({ msg: "User not found" });

    const valid = await bcrypt.compare(password, user[0].password);
    if (!valid) return res.status(400).json({ msg: "Invalid credentials" });

    const token = jwt.sign({ id: user[0].id, role: user[0].role }, "SECRETKEY", { expiresIn: "7d" });

    return res.json({ msg: "Loging success", token, role: user[0].role,name: user[0].name });
 

  } catch (err) {
    console.log(err);
    return res.status(500).json({ msg: "Server error" });
  }
});

// Protected Route Test
app.get("/admin-check", auth, (req, res) => {
  return res.json({ msg: "You are authenticated", user: req.user });
});
// GET ALL USERS
app.get("/admin/userss",auth, async (req, res) => {
  try {
    const [users] = await db.execute(
      "SELECT id, name, email, role,  created_at FROM userss ORDER BY id DESC"
    );

    return res.json(users);

  } catch (err) {
    console.log(err);
    return res.status(500).json({ msg: "Server error" });
  }
});

app.delete("/admin/userss/:id", auth, async (req, res) => {
  const { id } = req.params;
  try {
    await db.execute("DELETE FROM userss WHERE id = ?", [id]);
    return res.json({ msg: "User deleted successfully" });
  } catch (err) {
    console.log(err);
    return res.status(500).json({ msg: "Server error" });
  }
});
app.put("/admin/userss/:id", auth, async (req, res) => {
  const { id } = req.params;
  const { name, email, role } = req.body;

  try {
    await db.execute(
      "UPDATE userss SET name = ?, email = ?, role = ? WHERE id = ?",
      [name, email, role, id]
    );
    return res.json({ msg: "User updated successfully" });
  } catch (err) {
    console.log(err);
    return res.status(500).json({ msg: "Server error" });
  }
});


 //propertyadd
app.post("/property/add", auth, upload.fields([
  { name: "image", maxCount: 1 },
  { name: "documents", maxCount: 10 }
]), async (req, res) => {

  try {
    const { title, type, subtype, description, estimated_price, location } = req.body;

    const seller_id = req.user.id;
    const image = req.files.image ? req.files.image[0].filename : null;
    const documents = req.files.documents ? req.files.documents.map(f=>f.filename) : [];

    const [result] = await db.execute(
      `INSERT INTO propertie (seller_id,title,type,subtype,description,estimated_price,location,image,status)
       VALUES (?,?,?,?,?,?,?,?, 'pending')`,
      [seller_id, title, type, subtype, description, estimated_price, location, image]
    );

    return res.status(200).json({
      msg: "Property Added Successfully",
      id: result.insertId,
      docs: documents
    });

  } catch (err) {
    console.log(err);
    return res.status(500).json({ msg: "Server Error" });
  }
});

//get  propertyadd
app.get("/property/my", auth, async (req, res) => {
  try {
    const seller_id = req.user.id;

    const [rows] = await db.execute(
      "SELECT * FROM propertie WHERE seller_id=? ORDER BY id DESC",
      [seller_id]
    );

    // prepend uploads path for frontend
    const data = rows.map(row => ({
      ...row,
      image_url: row.image ? `http://localhost:5000/uploads/${row.image}` : null
    }));

    return res.json(data);

  } catch (err) {
    console.log(err);
    return res.status(500).json({ msg: "Server error" });
  }
});

//properties
app.get("/admin/properties", auth, async (req, res) => {
  try {
    const user = req.user;

    let query = `
      SELECT 
        p.id, 
        p.title, 
        p.type,
        p.subtype, 
        p.description,
        p.location, 
        p.estimated_price, 
        p.status,
        p.image,    
        u.name AS seller_name, 
        u.email AS seller_email
      FROM propertie p
      JOIN userss u ON p.seller_id = u.id
    `;

    const params = [];

    if (user.role === "seller") {
      query += ` WHERE p.seller_id = ?`;
      params.push(user.id);
    }

    query += ` ORDER BY p.id DESC`;

    const [rows] = await db.execute(query, params);

    res.json(rows);

  } catch (err) {
    console.log(err);
    res.status(500).json({ msg: "Server error" });
  }
});

app.patch("/admin/property/approve/:id", auth, async (req, res) => {
  const { id } = req.params;
  await db.execute(`UPDATE propertie SET status='approved' WHERE id=?`, [id]);
  res.json({ msg: "Property Approved" });
});
//"https/localhost:5000/admin/property/approve"

app.patch("/admin/property/reject/:id", auth, async (req, res) => {
  const { id } = req.params;
  await db.execute(`UPDATE propertie SET status='rejected' WHERE id=?`, [id]);
  res.json({ msg: "Property Rejected" });
});

app.delete("/admin/property/delete/:id", auth, async (req, res) => {
  const { id } = req.params;
  await db.execute(`DELETE FROM propertie WHERE id=?`, [id]);
  res.json({ msg: "Property Deleted" });
});

app.get("/buyer/properties", async (req, res) => {
  try {
    const [rows] = await db.execute(`
      SELECT id, title, location,subtype, image, estimated_price,description, type
      FROM propertie
      WHERE status = 'approved'
      ORDER BY id DESC
    `);

    // add image full path in response
    const data = rows.map(p => ({
      ...p,
      image_url: `http://localhost:5000/uploads/${p.image}`
    }));

    res.json(data);

  } catch (err) {
    console.log(err);
    res.status(500).json({ msg: "Server Error" });
  }
});
//investor###########
app.post("/investor/submit", async (req, res) => {
  try {
    const { name, address, email, phone, requirement, ticket_size } = req.body;

    await db.execute(
      "INSERT INTO investorss (name, address, email, phone, requirement, ticket_size) VALUES (?,?,?,?,?,?)",
      [name, address, email, phone, requirement, ticket_size]
    );

    return res.json({ msg: "Details Submitted, You can now view properties" });

  } catch (err) {
    console.log(err);
    return res.status(500).json({ msg: "Server Error" });
  }
});
app.get("/admin/investorss", auth, async (req, res) => {
  try {
    const [rows] = await db.execute("SELECT * FROM investorss ORDER BY id DESC");
    return res.json(rows);
  } catch (err) {
    console.log(err);
    return res.status(500).json({ msg: "Server Error" });
  }
});

app.delete("/admin/investorss/:id", auth, async (req, res) => {
  try {
    const { id } = req.params;
    await db.execute("DELETE FROM investorss WHERE id=?", [id]);
    return res.json({ msg: "Investor Deleted" });
  } catch (err) {
    console.log(err);
    return res.status(500).json({ msg: "Server Error" });
  }
});
 
app.post("/buyer-leads", async (req, res) => {
  try { 
    let {
      property_id,
      name,
      phone,
      reason,
      isDealer,
      timeToBuy,
      homeLoan,
      siteVisit
    } = req.body;

    // ✅ Validation
    if (!property_id || !name || !phone) {
      return res.status(400).json({ msg: "Required fields missing" });
    }

    // ✅ ENUM safety
    reason = reason === "selfuse" ? "selfuse" : "investment";
    isDealer = isDealer === "yes" ? "yes" : "no";
    timeToBuy = ["3months", "6months", "more"].includes(timeToBuy)
      ? timeToBuy
      : "3months";

    const sql = `
      INSERT INTO buyerleads
      (property_id, name, phone, reason, is_dealer, time_to_buy, home_loan, site_visit)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;

    await db.execute(sql, [
      property_id,
      name,
      phone,
      reason,
      isDealer,
      timeToBuy,
      Number(homeLoan),
      Number(siteVisit)
    ]);

    return res.status(201).json({ msg: "Buyer lead saved successfully" });

  } catch (error) {
    console.error("Buyer lead error:", error);
    return res.status(500).json({ msg: "Server error" });
  }
});

app.get("/buyer/properties", async (req, res) => {
  try {
    const {
      type,
      subtype,
      minPrice,
      maxPrice,
      location,
      postedBy
    } = req.query;

    let sql = `
      SELECT p.*, u.role AS postedBy
      FROM propertie p
      JOIN userss u ON p.seller_id = u.id
      WHERE p.status = 'approved'
    `;

    const params = [];

    if (type) {
      sql += " AND p.type = ?";
      params.push(type);
    }

    if (subtype) {
      sql += " AND p.subtype = ?";
      params.push(subtype);
    }

    if (minPrice) {
      sql += " AND p.estimated_price >= ?";
      params.push(minPrice);
    }

    if (maxPrice) {
      sql += " AND p.estimated_price <= ?";
      params.push(maxPrice);
    }

    if (location) {
      sql += " AND p.location = ?";
      params.push(location);
    }

    if (postedBy) {
      sql += " AND u.role = ?";
      params.push(postedBy);
    }

    sql += " ORDER BY p.created_at DESC";

    const [rows] = await db.execute(sql, params);
    res.json(rows);
  } catch (err) {
    console.log(err);
    res.status(500).json({ msg: "Server error" });
  }
});




 



// Server
const PORT = 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
